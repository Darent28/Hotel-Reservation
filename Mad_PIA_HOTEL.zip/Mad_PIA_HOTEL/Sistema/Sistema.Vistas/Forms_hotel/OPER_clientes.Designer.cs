﻿
namespace Sistema.Vistas.Forms_hotel
{
    partial class OPER_clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OPER_clientes));
            this.panel1 = new System.Windows.Forms.Panel();
            this.fechas = new System.Windows.Forms.Label();
            this.horas = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timerClientes = new System.Windows.Forms.Timer(this.components);
            this.textCelular = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textDomicilio = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dateTimeFechaNaci = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.textApeM = new System.Windows.Forms.TextBox();
            this.textNombres = new System.Windows.Forms.TextBox();
            this.textCorreo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnVerClientes = new System.Windows.Forms.Button();
            this.btnElimClientes = new System.Windows.Forms.Button();
            this.btnEditarClientes = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridClientes = new System.Windows.Forms.DataGridView();
            this.btnRegistrarClientes = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textApeP = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textID_user = new System.Windows.Forms.TextBox();
            this.comboBoxCivil = new System.Windows.Forms.ComboBox();
            this.comboRef = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.fechas);
            this.panel1.Controls.Add(this.horas);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-1, -6);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(984, 177);
            this.panel1.TabIndex = 0;
            // 
            // fechas
            // 
            this.fechas.AutoSize = true;
            this.fechas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fechas.ForeColor = System.Drawing.Color.White;
            this.fechas.Location = new System.Drawing.Point(664, 104);
            this.fechas.Name = "fechas";
            this.fechas.Size = new System.Drawing.Size(59, 23);
            this.fechas.TabIndex = 16;
            this.fechas.Text = "label6";
            // 
            // horas
            // 
            this.horas.AutoSize = true;
            this.horas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.horas.ForeColor = System.Drawing.Color.White;
            this.horas.Location = new System.Drawing.Point(363, 104);
            this.horas.Name = "horas";
            this.horas.Size = new System.Drawing.Size(59, 23);
            this.horas.TabIndex = 15;
            this.horas.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(549, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 23);
            this.label4.TabIndex = 14;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(582, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 23);
            this.label3.TabIndex = 13;
            this.label3.Text = "Fecha:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(299, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 23);
            this.label2.TabIndex = 12;
            this.label2.Text = "Hora:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(299, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 23);
            this.label1.TabIndex = 11;
            this.label1.Text = "Nombre del administrador:\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(108, 50);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(130, 83);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // timerClientes
            // 
            this.timerClientes.Enabled = true;
            this.timerClientes.Tick += new System.EventHandler(this.timerClientes_Tick);
            // 
            // textCelular
            // 
            this.textCelular.Location = new System.Drawing.Point(749, 285);
            this.textCelular.Name = "textCelular";
            this.textCelular.Size = new System.Drawing.Size(176, 30);
            this.textCelular.TabIndex = 118;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(610, 288);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(133, 23);
            this.label15.TabIndex = 117;
            this.label15.Text = "Teléfono celular:";
            // 
            // textDomicilio
            // 
            this.textDomicilio.Location = new System.Drawing.Point(701, 242);
            this.textDomicilio.Name = "textDomicilio";
            this.textDomicilio.Size = new System.Drawing.Size(224, 30);
            this.textDomicilio.TabIndex = 116;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(610, 245);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 23);
            this.label14.TabIndex = 115;
            this.label14.Text = "Domicilio:";
            // 
            // dateTimeFechaNaci
            // 
            this.dateTimeFechaNaci.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeFechaNaci.Location = new System.Drawing.Point(788, 199);
            this.dateTimeFechaNaci.Name = "dateTimeFechaNaci";
            this.dateTimeFechaNaci.Size = new System.Drawing.Size(137, 30);
            this.dateTimeFechaNaci.TabIndex = 114;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(610, 201);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(172, 23);
            this.label13.TabIndex = 113;
            this.label13.Text = "Fecha de nacimiento:";
            // 
            // textApeM
            // 
            this.textApeM.Location = new System.Drawing.Point(433, 373);
            this.textApeM.Name = "textApeM";
            this.textApeM.Size = new System.Drawing.Size(157, 30);
            this.textApeM.TabIndex = 111;
            // 
            // textNombres
            // 
            this.textNombres.Location = new System.Drawing.Point(433, 283);
            this.textNombres.Name = "textNombres";
            this.textNombres.Size = new System.Drawing.Size(157, 30);
            this.textNombres.TabIndex = 110;
            // 
            // textCorreo
            // 
            this.textCorreo.Location = new System.Drawing.Point(433, 242);
            this.textCorreo.Name = "textCorreo";
            this.textCorreo.Size = new System.Drawing.Size(157, 30);
            this.textCorreo.TabIndex = 108;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(271, 242);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 23);
            this.label7.TabIndex = 107;
            this.label7.Text = "Correo electrónico:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(280, 376);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 23);
            this.label6.TabIndex = 105;
            this.label6.Text = "Apellido materno:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(362, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 23);
            this.label5.TabIndex = 104;
            this.label5.Text = "RFC:";
            // 
            // btnVerClientes
            // 
            this.btnVerClientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnVerClientes.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerClientes.Location = new System.Drawing.Point(778, 564);
            this.btnVerClientes.Name = "btnVerClientes";
            this.btnVerClientes.Size = new System.Drawing.Size(128, 53);
            this.btnVerClientes.TabIndex = 103;
            this.btnVerClientes.Text = "Ver clientes";
            this.btnVerClientes.UseVisualStyleBackColor = false;
            // 
            // btnElimClientes
            // 
            this.btnElimClientes.BackColor = System.Drawing.Color.Red;
            this.btnElimClientes.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElimClientes.Location = new System.Drawing.Point(778, 700);
            this.btnElimClientes.Name = "btnElimClientes";
            this.btnElimClientes.Size = new System.Drawing.Size(128, 47);
            this.btnElimClientes.TabIndex = 102;
            this.btnElimClientes.Text = "Eliminar";
            this.btnElimClientes.UseVisualStyleBackColor = false;
            // 
            // btnEditarClientes
            // 
            this.btnEditarClientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEditarClientes.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarClientes.Location = new System.Drawing.Point(778, 633);
            this.btnEditarClientes.Name = "btnEditarClientes";
            this.btnEditarClientes.Size = new System.Drawing.Size(128, 50);
            this.btnEditarClientes.TabIndex = 101;
            this.btnEditarClientes.Text = "Editar";
            this.btnEditarClientes.UseVisualStyleBackColor = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(52, 501);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(632, 46);
            this.label12.TabIndex = 100;
            this.label12.Text = "Presione el botón \"Ver clientes\" para ver los clientes registrados en el sistema." +
    "\r\nDe click sobre la celda y oprima el botón con la opción que desea realizar al " +
    "dato.\r\n";
            // 
            // dataGridClientes
            // 
            this.dataGridClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridClientes.Location = new System.Drawing.Point(56, 564);
            this.dataGridClientes.Name = "dataGridClientes";
            this.dataGridClientes.ReadOnly = true;
            this.dataGridClientes.RowHeadersWidth = 51;
            this.dataGridClientes.RowTemplate.Height = 24;
            this.dataGridClientes.Size = new System.Drawing.Size(692, 183);
            this.dataGridClientes.TabIndex = 99;
            // 
            // btnRegistrarClientes
            // 
            this.btnRegistrarClientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnRegistrarClientes.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarClientes.Location = new System.Drawing.Point(682, 391);
            this.btnRegistrarClientes.Name = "btnRegistrarClientes";
            this.btnRegistrarClientes.Size = new System.Drawing.Size(243, 60);
            this.btnRegistrarClientes.TabIndex = 98;
            this.btnRegistrarClientes.Text = "Registrar";
            this.btnRegistrarClientes.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(56, 225);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(170, 166);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 97;
            this.pictureBox2.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(317, 286);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 23);
            this.label11.TabIndex = 96;
            this.label11.Text = "Nombre(s):";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(626, 331);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 23);
            this.label10.TabIndex = 95;
            this.label10.Text = "Estado civil:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(168, 423);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(292, 23);
            this.label9.TabIndex = 94;
            this.label9.Text = "Referencia de como conocio el hotel:";
            // 
            // textApeP
            // 
            this.textApeP.Location = new System.Drawing.Point(433, 331);
            this.textApeP.Name = "textApeP";
            this.textApeP.Size = new System.Drawing.Size(157, 30);
            this.textApeP.TabIndex = 93;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(285, 331);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(141, 23);
            this.label8.TabIndex = 92;
            this.label8.Text = "Apellido paterno:";
            // 
            // textID_user
            // 
            this.textID_user.Location = new System.Drawing.Point(433, 198);
            this.textID_user.Name = "textID_user";
            this.textID_user.Size = new System.Drawing.Size(157, 30);
            this.textID_user.TabIndex = 91;
            // 
            // comboBoxCivil
            // 
            this.comboBoxCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCivil.FormattingEnabled = true;
            this.comboBoxCivil.Location = new System.Drawing.Point(749, 328);
            this.comboBoxCivil.Name = "comboBoxCivil";
            this.comboBoxCivil.Size = new System.Drawing.Size(176, 31);
            this.comboBoxCivil.TabIndex = 119;
            // 
            // comboRef
            // 
            this.comboRef.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboRef.FormattingEnabled = true;
            this.comboRef.Location = new System.Drawing.Point(433, 420);
            this.comboRef.Name = "comboRef";
            this.comboRef.Size = new System.Drawing.Size(157, 31);
            this.comboRef.TabIndex = 120;
            // 
            // OPER_clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(982, 780);
            this.Controls.Add(this.comboRef);
            this.Controls.Add(this.comboBoxCivil);
            this.Controls.Add(this.textCelular);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.textDomicilio);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dateTimeFechaNaci);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textApeM);
            this.Controls.Add(this.textNombres);
            this.Controls.Add(this.textCorreo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnVerClientes);
            this.Controls.Add(this.btnElimClientes);
            this.Controls.Add(this.btnEditarClientes);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dataGridClientes);
            this.Controls.Add(this.btnRegistrarClientes);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textApeP);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textID_user);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "OPER_clientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrar clientes";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label fechas;
        private System.Windows.Forms.Label horas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timerClientes;
        private System.Windows.Forms.TextBox textCelular;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textDomicilio;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateTimeFechaNaci;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textApeM;
        private System.Windows.Forms.TextBox textNombres;
        private System.Windows.Forms.TextBox textCorreo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnVerClientes;
        private System.Windows.Forms.Button btnElimClientes;
        private System.Windows.Forms.Button btnEditarClientes;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridClientes;
        private System.Windows.Forms.Button btnRegistrarClientes;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textApeP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textID_user;
        private System.Windows.Forms.ComboBox comboBoxCivil;
        private System.Windows.Forms.ComboBox comboRef;
    }
}