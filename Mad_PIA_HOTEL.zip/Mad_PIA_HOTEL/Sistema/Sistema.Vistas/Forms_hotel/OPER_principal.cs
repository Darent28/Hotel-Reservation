﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema.Vistas.Forms_hotel
{
    public partial class OPER_principal : Form
    {
        public OPER_principal()
        {
            InitializeComponent();
        }

        private void timerOP_Tick(object sender, EventArgs e)
        {
            hora.Text = DateTime.Now.ToShortTimeString();
            fecha.Text = DateTime.Now.ToLongDateString();
        }

        private void registrarClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OPER_clientes paginaClientes = new OPER_clientes();
            paginaClientes.Show();
        }

        private void registrarReservaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OPER_reservacion paginaREsrv = new OPER_reservacion();
            paginaREsrv.Show();
        }
    }
}
