﻿
namespace Sistema.Vistas.Forms_hotel
{
    partial class ADMIN_hoteles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADMIN_hoteles));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.horas = new System.Windows.Forms.Label();
            this.fechas = new System.Windows.Forms.Label();
            this.tiempo = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textID_hotel = new System.Windows.Forms.TextBox();
            this.textNombre_hotel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textUbicacion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textDomicilio = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.numericPisos = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.numericHabitaciones = new System.Windows.Forms.NumericUpDown();
            this.checkZonaT = new System.Windows.Forms.CheckBox();
            this.checkServicios = new System.Windows.Forms.CheckBox();
            this.checkPlaya = new System.Windows.Forms.CheckBox();
            this.checkEventos = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnRegistrarH = new System.Windows.Forms.Button();
            this.dataGridHoteles = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnElim = new System.Windows.Forms.Button();
            this.btnVerHoteles = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPisos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericHabitaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHoteles)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.fechas);
            this.panel1.Controls.Add(this.horas);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(903, 117);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(38, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 58);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(208, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "Hora:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(208, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nombre del administrador:\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(459, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 23);
            this.label3.TabIndex = 6;
            this.label3.Text = "Fecha:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(430, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "label4";
            // 
            // horas
            // 
            this.horas.AutoSize = true;
            this.horas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.horas.ForeColor = System.Drawing.Color.White;
            this.horas.Location = new System.Drawing.Point(265, 67);
            this.horas.Name = "horas";
            this.horas.Size = new System.Drawing.Size(59, 23);
            this.horas.TabIndex = 8;
            this.horas.Text = "label5";
            // 
            // fechas
            // 
            this.fechas.AutoSize = true;
            this.fechas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fechas.ForeColor = System.Drawing.Color.White;
            this.fechas.Location = new System.Drawing.Point(532, 67);
            this.fechas.Name = "fechas";
            this.fechas.Size = new System.Drawing.Size(59, 23);
            this.fechas.TabIndex = 9;
            this.fechas.Text = "label6";
            // 
            // tiempo
            // 
            this.tiempo.Enabled = true;
            this.tiempo.Tick += new System.EventHandler(this.tiempo_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(227, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(413, 23);
            this.label5.TabIndex = 1;
            this.label5.Text = "Llene los siguientes campos para el registro del hotel";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(332, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 23);
            this.label6.TabIndex = 2;
            this.label6.Text = "ID del hotel:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(286, 242);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(149, 23);
            this.label7.TabIndex = 3;
            this.label7.Text = "Nombre del hotel:";
            // 
            // textID_hotel
            // 
            this.textID_hotel.Location = new System.Drawing.Point(445, 194);
            this.textID_hotel.Name = "textID_hotel";
            this.textID_hotel.Size = new System.Drawing.Size(146, 30);
            this.textID_hotel.TabIndex = 4;
            // 
            // textNombre_hotel
            // 
            this.textNombre_hotel.Location = new System.Drawing.Point(445, 239);
            this.textNombre_hotel.Name = "textNombre_hotel";
            this.textNombre_hotel.Size = new System.Drawing.Size(146, 30);
            this.textNombre_hotel.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(346, 279);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 23);
            this.label8.TabIndex = 6;
            this.label8.Text = "Ubicación:";
            // 
            // textUbicacion
            // 
            this.textUbicacion.Location = new System.Drawing.Point(445, 279);
            this.textUbicacion.Name = "textUbicacion";
            this.textUbicacion.Size = new System.Drawing.Size(146, 30);
            this.textUbicacion.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(350, 326);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 23);
            this.label9.TabIndex = 8;
            this.label9.Text = "Domicilio:";
            // 
            // textDomicilio
            // 
            this.textDomicilio.Location = new System.Drawing.Point(445, 323);
            this.textDomicilio.Name = "textDomicilio";
            this.textDomicilio.Size = new System.Drawing.Size(146, 30);
            this.textDomicilio.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(291, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(144, 23);
            this.label10.TabIndex = 10;
            this.label10.Text = "Número de pisos:";
            // 
            // numericPisos
            // 
            this.numericPisos.Location = new System.Drawing.Point(445, 367);
            this.numericPisos.Name = "numericPisos";
            this.numericPisos.Size = new System.Drawing.Size(100, 30);
            this.numericPisos.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(227, 411);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(208, 23);
            this.label11.TabIndex = 12;
            this.label11.Text = "Cantidad de habitaciones:";
            // 
            // numericHabitaciones
            // 
            this.numericHabitaciones.Location = new System.Drawing.Point(445, 409);
            this.numericHabitaciones.Name = "numericHabitaciones";
            this.numericHabitaciones.Size = new System.Drawing.Size(100, 30);
            this.numericHabitaciones.TabIndex = 13;
            // 
            // checkZonaT
            // 
            this.checkZonaT.AutoSize = true;
            this.checkZonaT.Location = new System.Drawing.Point(620, 199);
            this.checkZonaT.Name = "checkZonaT";
            this.checkZonaT.Size = new System.Drawing.Size(136, 27);
            this.checkZonaT.TabIndex = 18;
            this.checkZonaT.Text = "Zona túristica";
            this.checkZonaT.UseVisualStyleBackColor = true;
            // 
            // checkServicios
            // 
            this.checkServicios.AutoSize = true;
            this.checkServicios.Location = new System.Drawing.Point(620, 242);
            this.checkServicios.Name = "checkServicios";
            this.checkServicios.Size = new System.Drawing.Size(186, 27);
            this.checkServicios.TabIndex = 19;
            this.checkServicios.Text = "Servicios adicionales";
            this.checkServicios.UseVisualStyleBackColor = true;
            // 
            // checkPlaya
            // 
            this.checkPlaya.AutoSize = true;
            this.checkPlaya.Location = new System.Drawing.Point(620, 281);
            this.checkPlaya.Name = "checkPlaya";
            this.checkPlaya.Size = new System.Drawing.Size(157, 27);
            this.checkPlaya.TabIndex = 20;
            this.checkPlaya.Text = "Frente a la playa";
            this.checkPlaya.UseVisualStyleBackColor = true;
            // 
            // checkEventos
            // 
            this.checkEventos.AutoSize = true;
            this.checkEventos.Location = new System.Drawing.Point(620, 323);
            this.checkEventos.Name = "checkEventos";
            this.checkEventos.Size = new System.Drawing.Size(178, 27);
            this.checkEventos.TabIndex = 21;
            this.checkEventos.Text = "Salones de eventos";
            this.checkEventos.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(57, 208);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(170, 166);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // btnRegistrarH
            // 
            this.btnRegistrarH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnRegistrarH.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarH.Location = new System.Drawing.Point(620, 383);
            this.btnRegistrarH.Name = "btnRegistrarH";
            this.btnRegistrarH.Size = new System.Drawing.Size(186, 60);
            this.btnRegistrarH.TabIndex = 23;
            this.btnRegistrarH.Text = "Registrar";
            this.btnRegistrarH.UseVisualStyleBackColor = false;
            // 
            // dataGridHoteles
            // 
            this.dataGridHoteles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridHoteles.Location = new System.Drawing.Point(57, 559);
            this.dataGridHoteles.Name = "dataGridHoteles";
            this.dataGridHoteles.ReadOnly = true;
            this.dataGridHoteles.RowHeadersWidth = 51;
            this.dataGridHoteles.RowTemplate.Height = 24;
            this.dataGridHoteles.Size = new System.Drawing.Size(645, 183);
            this.dataGridHoteles.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(53, 491);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(632, 46);
            this.label12.TabIndex = 25;
            this.label12.Text = "Presione el botón \"Ver hoteles\" para ver los hoteles registrados en el sistema.\r\n" +
    "De click sobre la celda y oprima el botón con la opción que desea realizar al da" +
    "to.\r\n";
            // 
            // btnEditar
            // 
            this.btnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEditar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditar.Location = new System.Drawing.Point(731, 628);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(128, 47);
            this.btnEditar.TabIndex = 26;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = false;
            // 
            // btnElim
            // 
            this.btnElim.BackColor = System.Drawing.Color.Red;
            this.btnElim.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElim.Location = new System.Drawing.Point(731, 695);
            this.btnElim.Name = "btnElim";
            this.btnElim.Size = new System.Drawing.Size(128, 47);
            this.btnElim.TabIndex = 27;
            this.btnElim.Text = "Eliminar";
            this.btnElim.UseVisualStyleBackColor = false;
            // 
            // btnVerHoteles
            // 
            this.btnVerHoteles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnVerHoteles.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerHoteles.Location = new System.Drawing.Point(731, 559);
            this.btnVerHoteles.Name = "btnVerHoteles";
            this.btnVerHoteles.Size = new System.Drawing.Size(128, 46);
            this.btnVerHoteles.TabIndex = 28;
            this.btnVerHoteles.Text = "Ver hoteles";
            this.btnVerHoteles.UseVisualStyleBackColor = false;
            // 
            // ADMIN_hoteles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(900, 782);
            this.Controls.Add(this.btnVerHoteles);
            this.Controls.Add(this.btnElim);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dataGridHoteles);
            this.Controls.Add(this.btnRegistrarH);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.checkEventos);
            this.Controls.Add(this.checkPlaya);
            this.Controls.Add(this.checkServicios);
            this.Controls.Add(this.checkZonaT);
            this.Controls.Add(this.numericHabitaciones);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.numericPisos);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textDomicilio);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textUbicacion);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textNombre_hotel);
            this.Controls.Add(this.textID_hotel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "ADMIN_hoteles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrar hotel";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPisos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericHabitaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHoteles)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label fechas;
        private System.Windows.Forms.Label horas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer tiempo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textID_hotel;
        private System.Windows.Forms.TextBox textNombre_hotel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textUbicacion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textDomicilio;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericPisos;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericHabitaciones;
        private System.Windows.Forms.CheckBox checkZonaT;
        private System.Windows.Forms.CheckBox checkServicios;
        private System.Windows.Forms.CheckBox checkPlaya;
        private System.Windows.Forms.CheckBox checkEventos;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnRegistrarH;
        private System.Windows.Forms.DataGridView dataGridHoteles;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnElim;
        private System.Windows.Forms.Button btnVerHoteles;
    }
}