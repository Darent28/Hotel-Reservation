﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema.Vistas.Forms_hotel
{
    public partial class ADMIN_principal : Form
    {
        public ADMIN_principal()
        {
            InitializeComponent();
        }

        private void fechaHora_Tick(object sender, EventArgs e)
        {
            hora.Text = DateTime.Now.ToShortTimeString();
            fecha.Text = DateTime.Now.ToLongDateString();
        }

        private void hotelesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ADMIN_hoteles paginaRegisHotel = new ADMIN_hoteles();
            paginaRegisHotel.Show();
        }

        private void habitacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ADMIN_habitacion paginaRegisHabitacion = new ADMIN_habitacion();
            paginaRegisHabitacion.Show();
        }

        private void registroDeUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ADMIN_usuarios paginaUsuarios = new ADMIN_usuarios();
            paginaUsuarios.Show();          
        }

        private void reportesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ADMIN_reportes paginaReportes = new ADMIN_reportes();
            paginaReportes.Show();
        }
    }
}
