﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Entidad
{
    public class Checkin
    {
        public int id_checkin { get; set; }
        public int asistio { get; set; }
        public string codigo { get; set; }
    }
}
