﻿
namespace Sistema.Vistas.Forms_hotel
{
    partial class ADMIN_usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADMIN_usuarios));
            this.panel1 = new System.Windows.Forms.Panel();
            this.fechas = new System.Windows.Forms.Label();
            this.horas = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textCorreo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioOperario = new System.Windows.Forms.RadioButton();
            this.radioAdmin = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnVerUsers = new System.Windows.Forms.Button();
            this.btnElimUsers = new System.Windows.Forms.Button();
            this.btnEditarUsers = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridUsers = new System.Windows.Forms.DataGridView();
            this.btnRegistrarUser = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textApeP = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textIRFC = new System.Windows.Forms.TextBox();
            this.textContra = new System.Windows.Forms.TextBox();
            this.textNombres = new System.Windows.Forms.TextBox();
            this.textApeM = new System.Windows.Forms.TextBox();
            this.textNumNomina = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dateTimeFechaNaci = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.textDomicilio = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textCelular = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.fechas);
            this.panel1.Controls.Add(this.horas);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(904, 105);
            this.panel1.TabIndex = 2;
            // 
            // fechas
            // 
            this.fechas.AutoSize = true;
            this.fechas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fechas.ForeColor = System.Drawing.Color.White;
            this.fechas.Location = new System.Drawing.Point(473, 58);
            this.fechas.Name = "fechas";
            this.fechas.Size = new System.Drawing.Size(59, 23);
            this.fechas.TabIndex = 9;
            this.fechas.Text = "label6";
            // 
            // horas
            // 
            this.horas.AutoSize = true;
            this.horas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.horas.ForeColor = System.Drawing.Color.White;
            this.horas.Location = new System.Drawing.Point(236, 58);
            this.horas.Name = "horas";
            this.horas.Size = new System.Drawing.Size(59, 23);
            this.horas.TabIndex = 8;
            this.horas.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(382, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(408, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Fecha:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(185, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Hora:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(185, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nombre del administrador:\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(34, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // textCorreo
            // 
            this.textCorreo.Location = new System.Drawing.Point(384, 161);
            this.textCorreo.Name = "textCorreo";
            this.textCorreo.Size = new System.Drawing.Size(140, 27);
            this.textCorreo.TabIndex = 80;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(240, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 20);
            this.label7.TabIndex = 79;
            this.label7.Text = "Correo electrónico:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioOperario);
            this.groupBox1.Controls.Add(this.radioAdmin);
            this.groupBox1.Location = new System.Drawing.Point(545, 241);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(276, 70);
            this.groupBox1.TabIndex = 78;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Puesto";
            // 
            // radioOperario
            // 
            this.radioOperario.AutoSize = true;
            this.radioOperario.Location = new System.Drawing.Point(155, 32);
            this.radioOperario.Name = "radioOperario";
            this.radioOperario.Size = new System.Drawing.Size(89, 24);
            this.radioOperario.TabIndex = 1;
            this.radioOperario.Text = "Operario";
            this.radioOperario.UseVisualStyleBackColor = true;
            // 
            // radioAdmin
            // 
            this.radioAdmin.AutoSize = true;
            this.radioAdmin.Checked = true;
            this.radioAdmin.Location = new System.Drawing.Point(15, 32);
            this.radioAdmin.Name = "radioAdmin";
            this.radioAdmin.Size = new System.Drawing.Size(125, 24);
            this.radioAdmin.TabIndex = 0;
            this.radioAdmin.TabStop = true;
            this.radioAdmin.Text = "Administrador";
            this.radioAdmin.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(248, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 20);
            this.label6.TabIndex = 76;
            this.label6.Text = "Apellido materno:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(316, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 20);
            this.label5.TabIndex = 73;
            this.label5.Text = "RFC:";
            // 
            // btnVerUsers
            // 
            this.btnVerUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnVerUsers.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerUsers.Location = new System.Drawing.Point(693, 470);
            this.btnVerUsers.Name = "btnVerUsers";
            this.btnVerUsers.Size = new System.Drawing.Size(114, 46);
            this.btnVerUsers.TabIndex = 72;
            this.btnVerUsers.Text = "Ver usuarios";
            this.btnVerUsers.UseVisualStyleBackColor = false;
            this.btnVerUsers.Click += new System.EventHandler(this.btnVerUsers_Click);
            // 
            // btnElimUsers
            // 
            this.btnElimUsers.BackColor = System.Drawing.Color.Red;
            this.btnElimUsers.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElimUsers.Location = new System.Drawing.Point(693, 588);
            this.btnElimUsers.Name = "btnElimUsers";
            this.btnElimUsers.Size = new System.Drawing.Size(114, 41);
            this.btnElimUsers.TabIndex = 71;
            this.btnElimUsers.Text = "Eliminar";
            this.btnElimUsers.UseVisualStyleBackColor = false;
            this.btnElimUsers.Click += new System.EventHandler(this.btnElimUsers_Click);
            // 
            // btnEditarUsers
            // 
            this.btnEditarUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEditarUsers.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarUsers.Location = new System.Drawing.Point(693, 530);
            this.btnEditarUsers.Name = "btnEditarUsers";
            this.btnEditarUsers.Size = new System.Drawing.Size(114, 43);
            this.btnEditarUsers.TabIndex = 70;
            this.btnEditarUsers.Text = "Editar";
            this.btnEditarUsers.UseVisualStyleBackColor = false;
            this.btnEditarUsers.Click += new System.EventHandler(this.btnEditarUsers_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(45, 410);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(554, 40);
            this.label12.TabIndex = 69;
            this.label12.Text = "Presione el botón \"Ver usuarios\" para ver los usuarios registrados en el sistema." +
    "\r\nDe click sobre la celda y oprima el botón con la opción que desea realizar al " +
    "dato.\r\n";
            // 
            // dataGridUsers
            // 
            this.dataGridUsers.AllowUserToAddRows = false;
            this.dataGridUsers.AllowUserToDeleteRows = false;
            this.dataGridUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridUsers.Location = new System.Drawing.Point(49, 470);
            this.dataGridUsers.Name = "dataGridUsers";
            this.dataGridUsers.ReadOnly = true;
            this.dataGridUsers.RowHeadersWidth = 51;
            this.dataGridUsers.RowTemplate.Height = 24;
            this.dataGridUsers.Size = new System.Drawing.Size(615, 159);
            this.dataGridUsers.TabIndex = 68;
            this.dataGridUsers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridUsers_CellClick);
            // 
            // btnRegistrarUser
            // 
            this.btnRegistrarUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnRegistrarUser.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarUser.Location = new System.Drawing.Point(591, 330);
            this.btnRegistrarUser.Name = "btnRegistrarUser";
            this.btnRegistrarUser.Size = new System.Drawing.Size(216, 52);
            this.btnRegistrarUser.TabIndex = 67;
            this.btnRegistrarUser.Text = "Registrar";
            this.btnRegistrarUser.UseVisualStyleBackColor = false;
            this.btnRegistrarUser.Click += new System.EventHandler(this.btnRegistrarUser_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(49, 146);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(151, 144);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 66;
            this.pictureBox2.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(281, 238);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 20);
            this.label11.TabIndex = 65;
            this.label11.Text = "Nombre(s):";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(275, 195);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 20);
            this.label10.TabIndex = 63;
            this.label10.Text = "Contraseña:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(232, 356);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 20);
            this.label9.TabIndex = 62;
            this.label9.Text = "Número de nómina:";
            // 
            // textApeP
            // 
            this.textApeP.Location = new System.Drawing.Point(384, 277);
            this.textApeP.Name = "textApeP";
            this.textApeP.Size = new System.Drawing.Size(140, 27);
            this.textApeP.TabIndex = 61;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(247, 277);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 20);
            this.label8.TabIndex = 60;
            this.label8.Text = "Apellido paterno:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // textIRFC
            // 
            this.textIRFC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textIRFC.Location = new System.Drawing.Point(384, 123);
            this.textIRFC.MaxLength = 13;
            this.textIRFC.Name = "textIRFC";
            this.textIRFC.Size = new System.Drawing.Size(140, 27);
            this.textIRFC.TabIndex = 59;
            // 
            // textContra
            // 
            this.textContra.Location = new System.Drawing.Point(384, 195);
            this.textContra.Name = "textContra";
            this.textContra.Size = new System.Drawing.Size(140, 27);
            this.textContra.TabIndex = 81;
            this.textContra.UseSystemPasswordChar = true;
            // 
            // textNombres
            // 
            this.textNombres.Location = new System.Drawing.Point(384, 236);
            this.textNombres.Name = "textNombres";
            this.textNombres.Size = new System.Drawing.Size(140, 27);
            this.textNombres.TabIndex = 82;
            // 
            // textApeM
            // 
            this.textApeM.Location = new System.Drawing.Point(384, 314);
            this.textApeM.Name = "textApeM";
            this.textApeM.Size = new System.Drawing.Size(140, 27);
            this.textApeM.TabIndex = 83;
            // 
            // textNumNomina
            // 
            this.textNumNomina.Location = new System.Drawing.Point(384, 356);
            this.textNumNomina.MaxLength = 5;
            this.textNumNomina.Name = "textNumNomina";
            this.textNumNomina.Size = new System.Drawing.Size(140, 27);
            this.textNumNomina.TabIndex = 84;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(541, 125);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(149, 20);
            this.label13.TabIndex = 85;
            this.label13.Text = "Fecha de nacimiento:";
            // 
            // dateTimeFechaNaci
            // 
            this.dateTimeFechaNaci.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeFechaNaci.Location = new System.Drawing.Point(700, 120);
            this.dateTimeFechaNaci.Name = "dateTimeFechaNaci";
            this.dateTimeFechaNaci.Size = new System.Drawing.Size(122, 27);
            this.dateTimeFechaNaci.TabIndex = 86;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(541, 163);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 20);
            this.label14.TabIndex = 87;
            this.label14.Text = "Domicilio:";
            // 
            // textDomicilio
            // 
            this.textDomicilio.Location = new System.Drawing.Point(622, 161);
            this.textDomicilio.Name = "textDomicilio";
            this.textDomicilio.Size = new System.Drawing.Size(200, 27);
            this.textDomicilio.TabIndex = 88;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(541, 201);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(118, 20);
            this.label15.TabIndex = 89;
            this.label15.Text = "Teléfono celular:";
            // 
            // textCelular
            // 
            this.textCelular.Location = new System.Drawing.Point(665, 198);
            this.textCelular.MaxLength = 10;
            this.textCelular.Name = "textCelular";
            this.textCelular.Size = new System.Drawing.Size(157, 27);
            this.textCelular.TabIndex = 90;
            // 
            // ADMIN_usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(863, 666);
            this.Controls.Add(this.textCelular);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.textDomicilio);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dateTimeFechaNaci);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textNumNomina);
            this.Controls.Add(this.textApeM);
            this.Controls.Add(this.textNombres);
            this.Controls.Add(this.textContra);
            this.Controls.Add(this.textCorreo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnVerUsers);
            this.Controls.Add(this.btnElimUsers);
            this.Controls.Add(this.btnEditarUsers);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dataGridUsers);
            this.Controls.Add(this.btnRegistrarUser);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textApeP);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textIRFC);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ADMIN_usuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrar usuarios";
            this.Load += new System.EventHandler(this.ADMIN_usuarios_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label fechas;
        private System.Windows.Forms.Label horas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textCorreo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioOperario;
        private System.Windows.Forms.RadioButton radioAdmin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnVerUsers;
        private System.Windows.Forms.Button btnElimUsers;
        private System.Windows.Forms.Button btnEditarUsers;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridUsers;
        private System.Windows.Forms.Button btnRegistrarUser;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textApeP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textIRFC;
        private System.Windows.Forms.TextBox textContra;
        private System.Windows.Forms.TextBox textNombres;
        private System.Windows.Forms.TextBox textApeM;
        private System.Windows.Forms.TextBox textNumNomina;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dateTimeFechaNaci;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textDomicilio;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textCelular;
    }
}