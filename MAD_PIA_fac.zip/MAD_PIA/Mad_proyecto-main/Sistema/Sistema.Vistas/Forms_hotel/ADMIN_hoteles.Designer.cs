﻿
namespace Sistema.Vistas.Forms_hotel
{
    partial class ADMIN_hoteles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ADMIN_hoteles));
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelRFC = new System.Windows.Forms.Label();
            this.fechas = new System.Windows.Forms.Label();
            this.horas = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tiempo = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textNombre_hotel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textUbicacion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textDomicilio = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.numericPisos = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.numericHabitaciones = new System.Windows.Forms.NumericUpDown();
            this.checkZonaT = new System.Windows.Forms.CheckBox();
            this.checkServicios = new System.Windows.Forms.CheckBox();
            this.checkPlaya = new System.Windows.Forms.CheckBox();
            this.checkEventos = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnRegistrarH = new System.Windows.Forms.Button();
            this.dataGridHoteles = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnElim = new System.Windows.Forms.Button();
            this.btnVerHoteles = new System.Windows.Forms.Button();
            this.dateTimeFechaInicioOp = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.dateTimePickerFechaIngreso = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.textHotelID = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPisos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericHabitaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHoteles)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.labelRFC);
            this.panel1.Controls.Add(this.fechas);
            this.panel1.Controls.Add(this.horas);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(803, 102);
            this.panel1.TabIndex = 0;
            // 
            // labelRFC
            // 
            this.labelRFC.AutoSize = true;
            this.labelRFC.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRFC.ForeColor = System.Drawing.Color.White;
            this.labelRFC.Location = new System.Drawing.Point(564, 18);
            this.labelRFC.Name = "labelRFC";
            this.labelRFC.Size = new System.Drawing.Size(80, 23);
            this.labelRFC.TabIndex = 89;
            this.labelRFC.Text = "labelRFC";
            this.labelRFC.Visible = false;
            // 
            // fechas
            // 
            this.fechas.AutoSize = true;
            this.fechas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fechas.ForeColor = System.Drawing.Color.White;
            this.fechas.Location = new System.Drawing.Point(473, 58);
            this.fechas.Name = "fechas";
            this.fechas.Size = new System.Drawing.Size(59, 23);
            this.fechas.TabIndex = 9;
            this.fechas.Text = "label6";
            // 
            // horas
            // 
            this.horas.AutoSize = true;
            this.horas.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.horas.ForeColor = System.Drawing.Color.White;
            this.horas.Location = new System.Drawing.Point(236, 58);
            this.horas.Name = "horas";
            this.horas.Size = new System.Drawing.Size(59, 23);
            this.horas.TabIndex = 8;
            this.horas.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(382, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(408, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Fecha:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(185, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Hora:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(185, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nombre del administrador:\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(34, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tiempo
            // 
            this.tiempo.Enabled = true;
            this.tiempo.Tick += new System.EventHandler(this.tiempo_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(202, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(361, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Llene los siguientes campos para el registro del hotel";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(268, 173);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 20);
            this.label7.TabIndex = 3;
            this.label7.Text = "Nombre del hotel:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // textNombre_hotel
            // 
            this.textNombre_hotel.Location = new System.Drawing.Point(398, 173);
            this.textNombre_hotel.Name = "textNombre_hotel";
            this.textNombre_hotel.Size = new System.Drawing.Size(130, 27);
            this.textNombre_hotel.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(310, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "Ubicación:";
            // 
            // textUbicacion
            // 
            this.textUbicacion.Location = new System.Drawing.Point(398, 208);
            this.textUbicacion.Name = "textUbicacion";
            this.textUbicacion.Size = new System.Drawing.Size(130, 27);
            this.textUbicacion.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(304, 249);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Domicilio:";
            // 
            // textDomicilio
            // 
            this.textDomicilio.Location = new System.Drawing.Point(398, 246);
            this.textDomicilio.Name = "textDomicilio";
            this.textDomicilio.Size = new System.Drawing.Size(130, 27);
            this.textDomicilio.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(261, 286);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(125, 20);
            this.label10.TabIndex = 10;
            this.label10.Text = "Número de pisos:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // numericPisos
            // 
            this.numericPisos.Location = new System.Drawing.Point(398, 284);
            this.numericPisos.Name = "numericPisos";
            this.numericPisos.Size = new System.Drawing.Size(89, 27);
            this.numericPisos.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(217, 323);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(181, 20);
            this.label11.TabIndex = 12;
            this.label11.Text = "Cantidad de habitaciones:";
            // 
            // numericHabitaciones
            // 
            this.numericHabitaciones.Location = new System.Drawing.Point(398, 321);
            this.numericHabitaciones.Name = "numericHabitaciones";
            this.numericHabitaciones.Size = new System.Drawing.Size(89, 27);
            this.numericHabitaciones.TabIndex = 13;
            // 
            // checkZonaT
            // 
            this.checkZonaT.AutoSize = true;
            this.checkZonaT.Location = new System.Drawing.Point(551, 173);
            this.checkZonaT.Name = "checkZonaT";
            this.checkZonaT.Size = new System.Drawing.Size(121, 24);
            this.checkZonaT.TabIndex = 18;
            this.checkZonaT.Text = "Zona túristica";
            this.checkZonaT.UseVisualStyleBackColor = true;
            // 
            // checkServicios
            // 
            this.checkServicios.AutoSize = true;
            this.checkServicios.Location = new System.Drawing.Point(551, 210);
            this.checkServicios.Name = "checkServicios";
            this.checkServicios.Size = new System.Drawing.Size(168, 24);
            this.checkServicios.TabIndex = 19;
            this.checkServicios.Text = "Servicios adicionales";
            this.checkServicios.UseVisualStyleBackColor = true;
            // 
            // checkPlaya
            // 
            this.checkPlaya.AutoSize = true;
            this.checkPlaya.Location = new System.Drawing.Point(551, 244);
            this.checkPlaya.Name = "checkPlaya";
            this.checkPlaya.Size = new System.Drawing.Size(140, 24);
            this.checkPlaya.TabIndex = 20;
            this.checkPlaya.Text = "Frente a la playa";
            this.checkPlaya.UseVisualStyleBackColor = true;
            // 
            // checkEventos
            // 
            this.checkEventos.AutoSize = true;
            this.checkEventos.Location = new System.Drawing.Point(551, 281);
            this.checkEventos.Name = "checkEventos";
            this.checkEventos.Size = new System.Drawing.Size(158, 24);
            this.checkEventos.TabIndex = 21;
            this.checkEventos.Text = "Salones de eventos";
            this.checkEventos.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(51, 181);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(151, 144);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // btnRegistrarH
            // 
            this.btnRegistrarH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnRegistrarH.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarH.Location = new System.Drawing.Point(551, 333);
            this.btnRegistrarH.Name = "btnRegistrarH";
            this.btnRegistrarH.Size = new System.Drawing.Size(165, 52);
            this.btnRegistrarH.TabIndex = 23;
            this.btnRegistrarH.Text = "Registrar";
            this.btnRegistrarH.UseVisualStyleBackColor = false;
            this.btnRegistrarH.Click += new System.EventHandler(this.btnRegistrarH_Click);
            // 
            // dataGridHoteles
            // 
            this.dataGridHoteles.AllowUserToAddRows = false;
            this.dataGridHoteles.AllowUserToDeleteRows = false;
            this.dataGridHoteles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridHoteles.Location = new System.Drawing.Point(51, 486);
            this.dataGridHoteles.Name = "dataGridHoteles";
            this.dataGridHoteles.ReadOnly = true;
            this.dataGridHoteles.RowHeadersWidth = 51;
            this.dataGridHoteles.RowTemplate.Height = 24;
            this.dataGridHoteles.Size = new System.Drawing.Size(573, 159);
            this.dataGridHoteles.TabIndex = 24;
            this.dataGridHoteles.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridHoteles_CellClick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(47, 427);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(554, 40);
            this.label12.TabIndex = 25;
            this.label12.Text = "Presione el botón \"Ver hoteles\" para ver los hoteles registrados en el sistema.\r\n" +
    "De click sobre la celda y oprima el botón con la opción que desea realizar al da" +
    "to.\r\n";
            // 
            // btnEditar
            // 
            this.btnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnEditar.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditar.Location = new System.Drawing.Point(650, 546);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(114, 41);
            this.btnEditar.TabIndex = 26;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = false;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnElim
            // 
            this.btnElim.BackColor = System.Drawing.Color.Red;
            this.btnElim.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnElim.Location = new System.Drawing.Point(650, 604);
            this.btnElim.Name = "btnElim";
            this.btnElim.Size = new System.Drawing.Size(114, 41);
            this.btnElim.TabIndex = 27;
            this.btnElim.Text = "Eliminar";
            this.btnElim.UseVisualStyleBackColor = false;
            this.btnElim.Click += new System.EventHandler(this.btnElim_Click);
            // 
            // btnVerHoteles
            // 
            this.btnVerHoteles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnVerHoteles.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerHoteles.Location = new System.Drawing.Point(650, 486);
            this.btnVerHoteles.Name = "btnVerHoteles";
            this.btnVerHoteles.Size = new System.Drawing.Size(114, 40);
            this.btnVerHoteles.TabIndex = 28;
            this.btnVerHoteles.Text = "Ver hoteles";
            this.btnVerHoteles.UseVisualStyleBackColor = false;
            this.btnVerHoteles.Click += new System.EventHandler(this.btnVerHoteles_Click);
            // 
            // dateTimeFechaInicioOp
            // 
            this.dateTimeFechaInicioOp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeFechaInicioOp.Location = new System.Drawing.Point(398, 363);
            this.dateTimeFechaInicioOp.Name = "dateTimeFechaInicioOp";
            this.dateTimeFechaInicioOp.Size = new System.Drawing.Size(122, 27);
            this.dateTimeFechaInicioOp.TabIndex = 88;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(214, 368);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(186, 20);
            this.label13.TabIndex = 87;
            this.label13.Text = "Fecha inicio de operación :";
            // 
            // dateTimePickerFechaIngreso
            // 
            this.dateTimePickerFechaIngreso.Enabled = false;
            this.dateTimePickerFechaIngreso.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerFechaIngreso.Location = new System.Drawing.Point(398, 390);
            this.dateTimePickerFechaIngreso.Name = "dateTimePickerFechaIngreso";
            this.dateTimePickerFechaIngreso.Size = new System.Drawing.Size(122, 27);
            this.dateTimePickerFechaIngreso.TabIndex = 88;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(257, 396);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 20);
            this.label6.TabIndex = 87;
            this.label6.Text = "Fecha de registro :";
            // 
            // textHotelID
            // 
            this.textHotelID.Location = new System.Drawing.Point(398, 145);
            this.textHotelID.Name = "textHotelID";
            this.textHotelID.Size = new System.Drawing.Size(40, 27);
            this.textHotelID.TabIndex = 89;
            this.textHotelID.Visible = false;
            // 
            // ADMIN_hoteles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(800, 680);
            this.Controls.Add(this.textHotelID);
            this.Controls.Add(this.dateTimePickerFechaIngreso);
            this.Controls.Add(this.dateTimeFechaInicioOp);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnVerHoteles);
            this.Controls.Add(this.btnElim);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dataGridHoteles);
            this.Controls.Add(this.btnRegistrarH);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.checkEventos);
            this.Controls.Add(this.checkPlaya);
            this.Controls.Add(this.checkServicios);
            this.Controls.Add(this.checkZonaT);
            this.Controls.Add(this.numericHabitaciones);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.numericPisos);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textDomicilio);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textUbicacion);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textNombre_hotel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ADMIN_hoteles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrar hotel";
            this.Load += new System.EventHandler(this.ADMIN_hoteles_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPisos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericHabitaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHoteles)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label fechas;
        private System.Windows.Forms.Label horas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer tiempo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textNombre_hotel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textUbicacion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textDomicilio;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericPisos;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericHabitaciones;
        private System.Windows.Forms.CheckBox checkZonaT;
        private System.Windows.Forms.CheckBox checkServicios;
        private System.Windows.Forms.CheckBox checkPlaya;
        private System.Windows.Forms.CheckBox checkEventos;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnRegistrarH;
        private System.Windows.Forms.DataGridView dataGridHoteles;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnElim;
        private System.Windows.Forms.Button btnVerHoteles;
        private System.Windows.Forms.DateTimePicker dateTimeFechaInicioOp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dateTimePickerFechaIngreso;
        private System.Windows.Forms.Label labelRFC;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textHotelID;
    }
}